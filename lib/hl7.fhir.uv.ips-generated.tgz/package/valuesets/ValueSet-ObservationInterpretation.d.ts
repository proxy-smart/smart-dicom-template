/**
 * ValueSet: observation-interpretation
 * URL: http://hl7.org/fhir/ValueSet/observation-interpretation
 * Size: 57 concepts
 */
export declare const ObservationInterpretationConcepts: readonly [{
    readonly code: "_GeneticObservationInterpretation";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "CAR";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "Carrier";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "_ObservationInterpretationChange";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "B";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "D";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "U";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "W";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "_ObservationInterpretationExceptions";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "<";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: ">";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "AC";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "IE";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "QCF";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "TOX";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "_ObservationInterpretationNormality";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "A";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "AA";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "HH";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "LL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "H";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "H>";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "HU";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "L";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "L<";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "LU";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "N";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "_ObservationInterpretationSusceptibility";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "I";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "MS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "NCL";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "NS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "R";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "SYN-R";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "S";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "SDD";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "SYN-S";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "VS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "EX";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "HX";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "LX";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "HM";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "ObservationInterpretationDetection";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "IND";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "E";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "NEG";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "ND";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "POS";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "DET";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "ObservationInterpretationExpectation";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "EXP";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "UNE";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "OBX";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "ReactivityObservationInterpretation";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "NR";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "RR";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}, {
    readonly code: "WR";
    readonly system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation";
}];
/** String type (ValueSet too large for union type) */
export type ObservationInterpretationCode = string;
/** Type representing a concept from this ValueSet */
export type ObservationInterpretationConcept = typeof ObservationInterpretationConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidObservationInterpretationCode(code: string): code is ObservationInterpretationCode;
/**
 * Get concept details by code
 */
export declare function getObservationInterpretationConcept(code: string): ObservationInterpretationConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ObservationInterpretationCodes: ("E" | "<" | "N" | "U" | "L" | "R" | "HH" | "I" | "B" | "HM" | "A" | "D" | "S" | "W" | "_GeneticObservationInterpretation" | "CAR" | "Carrier" | "_ObservationInterpretationChange" | "_ObservationInterpretationExceptions" | ">" | "AC" | "IE" | "QCF" | "TOX" | "_ObservationInterpretationNormality" | "AA" | "LL" | "H" | "H>" | "HU" | "L<" | "LU" | "_ObservationInterpretationSusceptibility" | "MS" | "NCL" | "NS" | "SYN-R" | "SDD" | "SYN-S" | "VS" | "EX" | "HX" | "LX" | "ObservationInterpretationDetection" | "IND" | "NEG" | "ND" | "POS" | "DET" | "ObservationInterpretationExpectation" | "EXP" | "UNE" | "OBX" | "ReactivityObservationInterpretation" | "NR" | "RR" | "WR")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomObservationInterpretationCode(): ObservationInterpretationCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomObservationInterpretationConcept(): ObservationInterpretationConcept;
