/**
 * ValueSet: diagnostic-service-sections
 * URL: http://hl7.org/fhir/ValueSet/diagnostic-service-sections
 * Size: 45 concepts
 */
export const DiagnosticServiceSectionsConcepts = [
    { code: "AU", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "BG", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "BLB", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "CG", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "CH", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "CP", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "CT", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "CTH", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "CUS", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "EC", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "EN", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "GE", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "HM", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "ICU", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "IMG", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "IMM", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "LAB", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "MB", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "MCB", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "MYC", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "NMR", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "NMS", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "NRS", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "OSL", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "OT", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "OTH", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "OUS", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "PAR", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "PAT", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "PF", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "PHR", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "PHY", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "PT", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "RAD", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "RC", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "RT", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "RUS", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "RX", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "SP", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "SR", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "TX", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "URN", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "VR", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "VUS", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
    { code: "XRC", system: "http://terminology.hl7.org/CodeSystem/v2-0074" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidDiagnosticServiceSectionsCode(code) {
    return DiagnosticServiceSectionsConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getDiagnosticServiceSectionsConcept(code) {
    return DiagnosticServiceSectionsConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const DiagnosticServiceSectionsCodes = DiagnosticServiceSectionsConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomDiagnosticServiceSectionsCode() {
    return DiagnosticServiceSectionsCodes[Math.floor(Math.random() * DiagnosticServiceSectionsCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomDiagnosticServiceSectionsConcept() {
    return DiagnosticServiceSectionsConcepts[Math.floor(Math.random() * DiagnosticServiceSectionsConcepts.length)];
}
