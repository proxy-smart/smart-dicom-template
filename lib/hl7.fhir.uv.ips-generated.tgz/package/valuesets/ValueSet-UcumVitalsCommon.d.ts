/**
 * ValueSet: ucum-vitals-common
 * URL: http://hl7.org/fhir/ValueSet/ucum-vitals-common
 * Size: 12 concepts
 */
export declare const UcumVitalsCommonConcepts: readonly [{
    readonly code: "%";
    readonly system: "http://unitsofmeasure.org";
}, {
    readonly code: "cm";
    readonly system: "http://unitsofmeasure.org";
}, {
    readonly code: "[in_i]";
    readonly system: "http://unitsofmeasure.org";
}, {
    readonly code: "kg";
    readonly system: "http://unitsofmeasure.org";
}, {
    readonly code: "g";
    readonly system: "http://unitsofmeasure.org";
}, {
    readonly code: "[lb_av]";
    readonly system: "http://unitsofmeasure.org";
}, {
    readonly code: "Cel";
    readonly system: "http://unitsofmeasure.org";
}, {
    readonly code: "[degF]";
    readonly system: "http://unitsofmeasure.org";
}, {
    readonly code: "mm[Hg]";
    readonly system: "http://unitsofmeasure.org";
}, {
    readonly code: "/min";
    readonly system: "http://unitsofmeasure.org";
}, {
    readonly code: "kg/m2";
    readonly system: "http://unitsofmeasure.org";
}, {
    readonly code: "m2";
    readonly system: "http://unitsofmeasure.org";
}];
/** Union type of all valid codes in this ValueSet */
export type UcumVitalsCommonCode = "%" | "cm" | "[in_i]" | "kg" | "g" | "[lb_av]" | "Cel" | "[degF]" | "mm[Hg]" | "/min" | "kg/m2" | "m2";
/** Type representing a concept from this ValueSet */
export type UcumVitalsCommonConcept = typeof UcumVitalsCommonConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidUcumVitalsCommonCode(code: string): code is UcumVitalsCommonCode;
/**
 * Get concept details by code
 */
export declare function getUcumVitalsCommonConcept(code: string): UcumVitalsCommonConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const UcumVitalsCommonCodes: ("/min" | "Cel" | "kg" | "cm" | "kg/m2" | "%" | "mm[Hg]" | "[in_i]" | "g" | "[lb_av]" | "[degF]" | "m2")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomUcumVitalsCommonCode(): UcumVitalsCommonCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomUcumVitalsCommonConcept(): UcumVitalsCommonConcept;
