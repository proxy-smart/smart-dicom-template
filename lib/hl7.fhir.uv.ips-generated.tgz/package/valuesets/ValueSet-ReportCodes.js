/**
 * ValueSet: report-codes
 * URL: http://hl7.org/fhir/ValueSet/report-codes
 * Size: 31 concepts
 */
export const ReportCodesConcepts = [
    { code: "29463-7", system: "http://loinc.org" },
    { code: "8302-2", system: "http://loinc.org" },
    { code: "85354-9", system: "http://loinc.org" },
    { code: "8867-4", system: "http://loinc.org" },
    { code: "9279-1", system: "http://loinc.org" },
    { code: "8310-5", system: "http://loinc.org" },
    { code: "2708-6", system: "http://loinc.org" },
    { code: "39156-5", system: "http://loinc.org" },
    { code: "59408-5", system: "http://loinc.org" },
    { code: "8480-6", system: "http://loinc.org" },
    { code: "8462-4", system: "http://loinc.org" },
    { code: "718-7", system: "http://loinc.org" },
    { code: "2339-0", system: "http://loinc.org" },
    { code: "55284-4", system: "http://loinc.org" },
    { code: "3141-9", system: "http://loinc.org" },
    { code: "72166-2", system: "http://loinc.org" },
    { code: "11506-3", system: "http://loinc.org" },
    { code: "4548-4", system: "http://loinc.org" },
    { code: "2093-3", system: "http://loinc.org" },
    { code: "2571-8", system: "http://loinc.org" },
    { code: "6690-2", system: "http://loinc.org" },
    { code: "789-8", system: "http://loinc.org" },
    { code: "777-3", system: "http://loinc.org" },
    { code: "1742-6", system: "http://loinc.org" },
    { code: "1920-8", system: "http://loinc.org" },
    { code: "2160-0", system: "http://loinc.org" },
    { code: "3094-0", system: "http://loinc.org" },
    { code: "2823-3", system: "http://loinc.org" },
    { code: "2951-2", system: "http://loinc.org" },
    { code: "14959-1", system: "http://loinc.org" },
    { code: "82810-3", system: "http://loinc.org" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidReportCodesCode(code) {
    return ReportCodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getReportCodesConcept(code) {
    return ReportCodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ReportCodesCodes = ReportCodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomReportCodesCode() {
    return ReportCodesCodes[Math.floor(Math.random() * ReportCodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomReportCodesConcept() {
    return ReportCodesConcepts[Math.floor(Math.random() * ReportCodesConcepts.length)];
}
