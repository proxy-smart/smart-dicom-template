/**
 * ValueSet: observation-interpretation
 * URL: http://hl7.org/fhir/ValueSet/observation-interpretation
 * Size: 57 concepts
 */
export const ObservationInterpretationConcepts = [
    { code: "_GeneticObservationInterpretation", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "CAR", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "Carrier", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "_ObservationInterpretationChange", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "B", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "D", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "U", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "W", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "_ObservationInterpretationExceptions", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "<", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: ">", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "AC", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "IE", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "QCF", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "TOX", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "_ObservationInterpretationNormality", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "A", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "AA", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "HH", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "LL", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "H", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "H>", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "HU", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "L", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "L<", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "LU", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "N", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "_ObservationInterpretationSusceptibility", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "I", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "MS", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "NCL", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "NS", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "R", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "SYN-R", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "S", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "SDD", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "SYN-S", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "VS", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "EX", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "HX", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "LX", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "HM", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "ObservationInterpretationDetection", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "IND", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "E", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "NEG", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "ND", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "POS", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "DET", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "ObservationInterpretationExpectation", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "EXP", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "UNE", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "OBX", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "ReactivityObservationInterpretation", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "NR", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "RR", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
    { code: "WR", system: "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidObservationInterpretationCode(code) {
    return ObservationInterpretationConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getObservationInterpretationConcept(code) {
    return ObservationInterpretationConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ObservationInterpretationCodes = ObservationInterpretationConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomObservationInterpretationCode() {
    return ObservationInterpretationCodes[Math.floor(Math.random() * ObservationInterpretationCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomObservationInterpretationConcept() {
    return ObservationInterpretationConcepts[Math.floor(Math.random() * ObservationInterpretationConcepts.length)];
}
