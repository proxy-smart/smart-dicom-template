/**
 * ValueSet: body-site
 * URL: http://hl7.org/fhir/ValueSet/body-site
 * Size: 15 concepts
 */
export const BodySiteConcepts = [
    { code: "27113001", system: "http://snomed.info/sct" },
    { code: "50373000", system: "http://snomed.info/sct" },
    { code: "75367002", system: "http://snomed.info/sct" },
    { code: "364075005", system: "http://snomed.info/sct" },
    { code: "86290005", system: "http://snomed.info/sct" },
    { code: "386725007", system: "http://snomed.info/sct" },
    { code: "431314004", system: "http://snomed.info/sct" },
    { code: "60621009", system: "http://snomed.info/sct" },
    { code: "271649006", system: "http://snomed.info/sct" },
    { code: "271650006", system: "http://snomed.info/sct" },
    { code: "404684003", system: "http://snomed.info/sct" },
    { code: "118228005", system: "http://snomed.info/sct" },
    { code: "250171008", system: "http://snomed.info/sct" },
    { code: "363787002", system: "http://snomed.info/sct" },
    { code: "386661006", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidBodySiteCode(code) {
    return BodySiteConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getBodySiteConcept(code) {
    return BodySiteConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const BodySiteCodes = BodySiteConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomBodySiteCode() {
    return BodySiteCodes[Math.floor(Math.random() * BodySiteCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomBodySiteConcept() {
    return BodySiteConcepts[Math.floor(Math.random() * BodySiteConcepts.length)];
}
