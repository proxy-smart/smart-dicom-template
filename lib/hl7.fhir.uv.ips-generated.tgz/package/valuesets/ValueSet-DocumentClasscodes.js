/**
 * ValueSet: document-classcodes
 * URL: http://hl7.org/fhir/ValueSet/document-classcodes
 * Size: 45 concepts
 */
export const DocumentClasscodesConcepts = [
    { code: "11369-6", system: "http://loinc.org" },
    { code: "11485-0", system: "http://loinc.org" },
    { code: "11486-8", system: "http://loinc.org" },
    { code: "11488-4", system: "http://loinc.org" },
    { code: "11506-3", system: "http://loinc.org" },
    { code: "11543-6", system: "http://loinc.org" },
    { code: "15508-5", system: "http://loinc.org" },
    { code: "18726-0", system: "http://loinc.org" },
    { code: "18761-7", system: "http://loinc.org" },
    { code: "18842-5", system: "http://loinc.org" },
    { code: "26436-6", system: "http://loinc.org" },
    { code: "26441-6", system: "http://loinc.org" },
    { code: "26442-4", system: "http://loinc.org" },
    { code: "27895-2", system: "http://loinc.org" },
    { code: "27896-0", system: "http://loinc.org" },
    { code: "27897-8", system: "http://loinc.org" },
    { code: "27898-6", system: "http://loinc.org" },
    { code: "28570-0", system: "http://loinc.org" },
    { code: "28619-5", system: "http://loinc.org" },
    { code: "28634-4", system: "http://loinc.org" },
    { code: "29749-9", system: "http://loinc.org" },
    { code: "29750-7", system: "http://loinc.org" },
    { code: "29751-5", system: "http://loinc.org" },
    { code: "29752-3", system: "http://loinc.org" },
    { code: "34109-9", system: "http://loinc.org" },
    { code: "34117-2", system: "http://loinc.org" },
    { code: "34121-4", system: "http://loinc.org" },
    { code: "34122-2", system: "http://loinc.org" },
    { code: "34133-9", system: "http://loinc.org" },
    { code: "34140-4", system: "http://loinc.org" },
    { code: "34748-4", system: "http://loinc.org" },
    { code: "34775-7", system: "http://loinc.org" },
    { code: "47039-3", system: "http://loinc.org" },
    { code: "47042-7", system: "http://loinc.org" },
    { code: "47045-0", system: "http://loinc.org" },
    { code: "47046-8", system: "http://loinc.org" },
    { code: "47049-2", system: "http://loinc.org" },
    { code: "57017-6", system: "http://loinc.org" },
    { code: "57016-8", system: "http://loinc.org" },
    { code: "56445-0", system: "http://loinc.org" },
    { code: "53576-5", system: "http://loinc.org" },
    { code: "56447-6", system: "http://loinc.org" },
    { code: "18748-4", system: "http://loinc.org" },
    { code: "11504-8", system: "http://loinc.org" },
    { code: "57133-1", system: "http://loinc.org" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidDocumentClasscodesCode(code) {
    return DocumentClasscodesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getDocumentClasscodesConcept(code) {
    return DocumentClasscodesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const DocumentClasscodesCodes = DocumentClasscodesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomDocumentClasscodesCode() {
    return DocumentClasscodesCodes[Math.floor(Math.random() * DocumentClasscodesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomDocumentClasscodesConcept() {
    return DocumentClasscodesConcepts[Math.floor(Math.random() * DocumentClasscodesConcepts.length)];
}
