/**
 * ValueSet: observation-vitalsignresult
 * URL: http://hl7.org/fhir/ValueSet/observation-vitalsignresult
 * Size: 13 concepts
 */
export const ObservationVitalsignresultConcepts = [
    { code: "85353-1", system: "http://loinc.org" },
    { code: "9279-1", system: "http://loinc.org" },
    { code: "8867-4", system: "http://loinc.org" },
    { code: "2708-6", system: "http://loinc.org" },
    { code: "8310-5", system: "http://loinc.org" },
    { code: "8302-2", system: "http://loinc.org" },
    { code: "9843-4", system: "http://loinc.org" },
    { code: "29463-7", system: "http://loinc.org" },
    { code: "39156-5", system: "http://loinc.org" },
    { code: "85354-9", system: "http://loinc.org" },
    { code: "8480-6", system: "http://loinc.org" },
    { code: "8462-4", system: "http://loinc.org" },
    { code: "8478-0", system: "http://loinc.org" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidObservationVitalsignresultCode(code) {
    return ObservationVitalsignresultConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getObservationVitalsignresultConcept(code) {
    return ObservationVitalsignresultConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ObservationVitalsignresultCodes = ObservationVitalsignresultConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomObservationVitalsignresultCode() {
    return ObservationVitalsignresultCodes[Math.floor(Math.random() * ObservationVitalsignresultCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomObservationVitalsignresultConcept() {
    return ObservationVitalsignresultConcepts[Math.floor(Math.random() * ObservationVitalsignresultConcepts.length)];
}
