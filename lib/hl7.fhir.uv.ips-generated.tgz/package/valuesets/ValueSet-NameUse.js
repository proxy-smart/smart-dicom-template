/**
 * ValueSet: name-use
 * URL: http://hl7.org/fhir/ValueSet/name-use
 * Size: 7 concepts
 */
export const NameUseConcepts = [
    { code: "usual", system: "http://hl7.org/fhir/name-use" },
    { code: "official", system: "http://hl7.org/fhir/name-use" },
    { code: "temp", system: "http://hl7.org/fhir/name-use" },
    { code: "nickname", system: "http://hl7.org/fhir/name-use" },
    { code: "anonymous", system: "http://hl7.org/fhir/name-use" },
    { code: "old", system: "http://hl7.org/fhir/name-use" },
    { code: "maiden", system: "http://hl7.org/fhir/name-use" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidNameUseCode(code) {
    return NameUseConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getNameUseConcept(code) {
    return NameUseConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const NameUseCodes = NameUseConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomNameUseCode() {
    return NameUseCodes[Math.floor(Math.random() * NameUseCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomNameUseConcept() {
    return NameUseConcepts[Math.floor(Math.random() * NameUseConcepts.length)];
}
