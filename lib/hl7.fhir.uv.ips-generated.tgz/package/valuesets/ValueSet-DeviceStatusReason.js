/**
 * ValueSet: device-status-reason
 * URL: http://hl7.org/fhir/ValueSet/device-status-reason
 * Size: 8 concepts
 */
export const DeviceStatusReasonConcepts = [
    { code: "online", system: "http://terminology.hl7.org/CodeSystem/device-status-reason" },
    { code: "paused", system: "http://terminology.hl7.org/CodeSystem/device-status-reason" },
    { code: "standby", system: "http://terminology.hl7.org/CodeSystem/device-status-reason" },
    { code: "offline", system: "http://terminology.hl7.org/CodeSystem/device-status-reason" },
    { code: "not-ready", system: "http://terminology.hl7.org/CodeSystem/device-status-reason" },
    { code: "transduc-discon", system: "http://terminology.hl7.org/CodeSystem/device-status-reason" },
    { code: "hw-discon", system: "http://terminology.hl7.org/CodeSystem/device-status-reason" },
    { code: "off", system: "http://terminology.hl7.org/CodeSystem/device-status-reason" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidDeviceStatusReasonCode(code) {
    return DeviceStatusReasonConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getDeviceStatusReasonConcept(code) {
    return DeviceStatusReasonConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const DeviceStatusReasonCodes = DeviceStatusReasonConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomDeviceStatusReasonCode() {
    return DeviceStatusReasonCodes[Math.floor(Math.random() * DeviceStatusReasonCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomDeviceStatusReasonConcept() {
    return DeviceStatusReasonConcepts[Math.floor(Math.random() * DeviceStatusReasonConcepts.length)];
}
