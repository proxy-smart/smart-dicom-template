/**
 * ValueSet: condition-code
 * URL: http://hl7.org/fhir/ValueSet/condition-code
 * Size: 1 concepts
 */
export const ConditionCodeConcepts = [
    { code: "160245001", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidConditionCodeCode(code) {
    return ConditionCodeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getConditionCodeConcept(code) {
    return ConditionCodeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ConditionCodeCodes = ConditionCodeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomConditionCodeCode() {
    return ConditionCodeCodes[Math.floor(Math.random() * ConditionCodeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomConditionCodeConcept() {
    return ConditionCodeConcepts[Math.floor(Math.random() * ConditionCodeConcepts.length)];
}
