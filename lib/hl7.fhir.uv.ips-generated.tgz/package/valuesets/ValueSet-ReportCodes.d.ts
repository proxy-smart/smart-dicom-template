/**
 * ValueSet: report-codes
 * URL: http://hl7.org/fhir/ValueSet/report-codes
 * Size: 31 concepts
 */
export declare const ReportCodesConcepts: readonly [{
    readonly code: "29463-7";
    readonly system: "http://loinc.org";
}, {
    readonly code: "8302-2";
    readonly system: "http://loinc.org";
}, {
    readonly code: "85354-9";
    readonly system: "http://loinc.org";
}, {
    readonly code: "8867-4";
    readonly system: "http://loinc.org";
}, {
    readonly code: "9279-1";
    readonly system: "http://loinc.org";
}, {
    readonly code: "8310-5";
    readonly system: "http://loinc.org";
}, {
    readonly code: "2708-6";
    readonly system: "http://loinc.org";
}, {
    readonly code: "39156-5";
    readonly system: "http://loinc.org";
}, {
    readonly code: "59408-5";
    readonly system: "http://loinc.org";
}, {
    readonly code: "8480-6";
    readonly system: "http://loinc.org";
}, {
    readonly code: "8462-4";
    readonly system: "http://loinc.org";
}, {
    readonly code: "718-7";
    readonly system: "http://loinc.org";
}, {
    readonly code: "2339-0";
    readonly system: "http://loinc.org";
}, {
    readonly code: "55284-4";
    readonly system: "http://loinc.org";
}, {
    readonly code: "3141-9";
    readonly system: "http://loinc.org";
}, {
    readonly code: "72166-2";
    readonly system: "http://loinc.org";
}, {
    readonly code: "11506-3";
    readonly system: "http://loinc.org";
}, {
    readonly code: "4548-4";
    readonly system: "http://loinc.org";
}, {
    readonly code: "2093-3";
    readonly system: "http://loinc.org";
}, {
    readonly code: "2571-8";
    readonly system: "http://loinc.org";
}, {
    readonly code: "6690-2";
    readonly system: "http://loinc.org";
}, {
    readonly code: "789-8";
    readonly system: "http://loinc.org";
}, {
    readonly code: "777-3";
    readonly system: "http://loinc.org";
}, {
    readonly code: "1742-6";
    readonly system: "http://loinc.org";
}, {
    readonly code: "1920-8";
    readonly system: "http://loinc.org";
}, {
    readonly code: "2160-0";
    readonly system: "http://loinc.org";
}, {
    readonly code: "3094-0";
    readonly system: "http://loinc.org";
}, {
    readonly code: "2823-3";
    readonly system: "http://loinc.org";
}, {
    readonly code: "2951-2";
    readonly system: "http://loinc.org";
}, {
    readonly code: "14959-1";
    readonly system: "http://loinc.org";
}, {
    readonly code: "82810-3";
    readonly system: "http://loinc.org";
}];
/** String type (ValueSet too large for union type) */
export type ReportCodesCode = string;
/** Type representing a concept from this ValueSet */
export type ReportCodesConcept = typeof ReportCodesConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidReportCodesCode(code: string): code is ReportCodesCode;
/**
 * Get concept details by code
 */
export declare function getReportCodesConcept(code: string): ReportCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ReportCodesCodes: ("4548-4" | "8867-4" | "9279-1" | "8310-5" | "29463-7" | "3141-9" | "8302-2" | "39156-5" | "2708-6" | "59408-5" | "8480-6" | "8462-4" | "718-7" | "82810-3" | "72166-2" | "85354-9" | "11506-3" | "2339-0" | "55284-4" | "2093-3" | "2571-8" | "6690-2" | "789-8" | "777-3" | "1742-6" | "1920-8" | "2160-0" | "3094-0" | "2823-3" | "2951-2" | "14959-1")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomReportCodesCode(): ReportCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomReportCodesConcept(): ReportCodesConcept;
