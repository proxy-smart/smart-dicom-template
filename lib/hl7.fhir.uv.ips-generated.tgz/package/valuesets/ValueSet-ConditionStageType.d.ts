/**
 * ValueSet: condition-stage-type
 * URL: http://hl7.org/fhir/ValueSet/condition-stage-type
 * Size: 2 concepts
 */
export declare const ConditionStageTypeConcepts: readonly [{
    readonly code: "261023001";
    readonly system: "http://snomed.info/sct";
}, {
    readonly code: "260998006";
    readonly system: "http://snomed.info/sct";
}];
/** Union type of all valid codes in this ValueSet */
export type ConditionStageTypeCode = "261023001" | "260998006";
/** Type representing a concept from this ValueSet */
export type ConditionStageTypeConcept = typeof ConditionStageTypeConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidConditionStageTypeCode(code: string): code is ConditionStageTypeCode;
/**
 * Get concept details by code
 */
export declare function getConditionStageTypeConcept(code: string): ConditionStageTypeConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ConditionStageTypeCodes: ("261023001" | "260998006")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomConditionStageTypeCode(): ConditionStageTypeCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomConditionStageTypeConcept(): ConditionStageTypeConcept;
