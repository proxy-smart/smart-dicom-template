/**
 * ValueSet: languages
 * URL: http://hl7.org/fhir/ValueSet/languages
 * Size: 56 concepts
 */
export const LanguagesConcepts = [
    { code: "ar", system: "urn:ietf:bcp:47" },
    { code: "bn", system: "urn:ietf:bcp:47" },
    { code: "cs", system: "urn:ietf:bcp:47" },
    { code: "da", system: "urn:ietf:bcp:47" },
    { code: "de", system: "urn:ietf:bcp:47" },
    { code: "de-AT", system: "urn:ietf:bcp:47" },
    { code: "de-CH", system: "urn:ietf:bcp:47" },
    { code: "de-DE", system: "urn:ietf:bcp:47" },
    { code: "el", system: "urn:ietf:bcp:47" },
    { code: "en", system: "urn:ietf:bcp:47" },
    { code: "en-AU", system: "urn:ietf:bcp:47" },
    { code: "en-CA", system: "urn:ietf:bcp:47" },
    { code: "en-GB", system: "urn:ietf:bcp:47" },
    { code: "en-IN", system: "urn:ietf:bcp:47" },
    { code: "en-NZ", system: "urn:ietf:bcp:47" },
    { code: "en-SG", system: "urn:ietf:bcp:47" },
    { code: "en-US", system: "urn:ietf:bcp:47" },
    { code: "es", system: "urn:ietf:bcp:47" },
    { code: "es-AR", system: "urn:ietf:bcp:47" },
    { code: "es-ES", system: "urn:ietf:bcp:47" },
    { code: "es-UY", system: "urn:ietf:bcp:47" },
    { code: "fi", system: "urn:ietf:bcp:47" },
    { code: "fr", system: "urn:ietf:bcp:47" },
    { code: "fr-BE", system: "urn:ietf:bcp:47" },
    { code: "fr-CH", system: "urn:ietf:bcp:47" },
    { code: "fr-FR", system: "urn:ietf:bcp:47" },
    { code: "fy", system: "urn:ietf:bcp:47" },
    { code: "fy-NL", system: "urn:ietf:bcp:47" },
    { code: "hi", system: "urn:ietf:bcp:47" },
    { code: "hr", system: "urn:ietf:bcp:47" },
    { code: "it", system: "urn:ietf:bcp:47" },
    { code: "it-CH", system: "urn:ietf:bcp:47" },
    { code: "it-IT", system: "urn:ietf:bcp:47" },
    { code: "ja", system: "urn:ietf:bcp:47" },
    { code: "ko", system: "urn:ietf:bcp:47" },
    { code: "nl", system: "urn:ietf:bcp:47" },
    { code: "nl-BE", system: "urn:ietf:bcp:47" },
    { code: "nl-NL", system: "urn:ietf:bcp:47" },
    { code: "no", system: "urn:ietf:bcp:47" },
    { code: "no-NO", system: "urn:ietf:bcp:47" },
    { code: "pa", system: "urn:ietf:bcp:47" },
    { code: "pl", system: "urn:ietf:bcp:47" },
    { code: "pt", system: "urn:ietf:bcp:47" },
    { code: "pt-BR", system: "urn:ietf:bcp:47" },
    { code: "ru", system: "urn:ietf:bcp:47" },
    { code: "ru-RU", system: "urn:ietf:bcp:47" },
    { code: "sr", system: "urn:ietf:bcp:47" },
    { code: "sr-RS", system: "urn:ietf:bcp:47" },
    { code: "sv", system: "urn:ietf:bcp:47" },
    { code: "sv-SE", system: "urn:ietf:bcp:47" },
    { code: "te", system: "urn:ietf:bcp:47" },
    { code: "zh", system: "urn:ietf:bcp:47" },
    { code: "zh-CN", system: "urn:ietf:bcp:47" },
    { code: "zh-HK", system: "urn:ietf:bcp:47" },
    { code: "zh-SG", system: "urn:ietf:bcp:47" },
    { code: "zh-TW", system: "urn:ietf:bcp:47" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidLanguagesCode(code) {
    return LanguagesConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getLanguagesConcept(code) {
    return LanguagesConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const LanguagesCodes = LanguagesConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomLanguagesCode() {
    return LanguagesCodes[Math.floor(Math.random() * LanguagesCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomLanguagesConcept() {
    return LanguagesConcepts[Math.floor(Math.random() * LanguagesConcepts.length)];
}
