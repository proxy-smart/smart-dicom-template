/**
 * ValueSet: observation-vitalsignresult
 * URL: http://hl7.org/fhir/ValueSet/observation-vitalsignresult
 * Size: 13 concepts
 */
export declare const ObservationVitalsignresultConcepts: readonly [{
    readonly code: "85353-1";
    readonly system: "http://loinc.org";
}, {
    readonly code: "9279-1";
    readonly system: "http://loinc.org";
}, {
    readonly code: "8867-4";
    readonly system: "http://loinc.org";
}, {
    readonly code: "2708-6";
    readonly system: "http://loinc.org";
}, {
    readonly code: "8310-5";
    readonly system: "http://loinc.org";
}, {
    readonly code: "8302-2";
    readonly system: "http://loinc.org";
}, {
    readonly code: "9843-4";
    readonly system: "http://loinc.org";
}, {
    readonly code: "29463-7";
    readonly system: "http://loinc.org";
}, {
    readonly code: "39156-5";
    readonly system: "http://loinc.org";
}, {
    readonly code: "85354-9";
    readonly system: "http://loinc.org";
}, {
    readonly code: "8480-6";
    readonly system: "http://loinc.org";
}, {
    readonly code: "8462-4";
    readonly system: "http://loinc.org";
}, {
    readonly code: "8478-0";
    readonly system: "http://loinc.org";
}];
/** Union type of all valid codes in this ValueSet */
export type ObservationVitalsignresultCode = "85353-1" | "9279-1" | "8867-4" | "2708-6" | "8310-5" | "8302-2" | "9843-4" | "29463-7" | "39156-5" | "85354-9" | "8480-6" | "8462-4" | "8478-0";
/** Type representing a concept from this ValueSet */
export type ObservationVitalsignresultConcept = typeof ObservationVitalsignresultConcepts[number];
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidObservationVitalsignresultCode(code: string): code is ObservationVitalsignresultCode;
/**
 * Get concept details by code
 */
export declare function getObservationVitalsignresultConcept(code: string): ObservationVitalsignresultConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ObservationVitalsignresultCodes: ("8867-4" | "9279-1" | "8310-5" | "29463-7" | "8302-2" | "39156-5" | "2708-6" | "8480-6" | "8462-4" | "85353-1" | "9843-4" | "85354-9" | "8478-0")[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomObservationVitalsignresultCode(): ObservationVitalsignresultCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomObservationVitalsignresultConcept(): ObservationVitalsignresultConcept;
