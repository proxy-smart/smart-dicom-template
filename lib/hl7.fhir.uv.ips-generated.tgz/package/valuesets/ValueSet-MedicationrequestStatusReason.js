/**
 * ValueSet: medicationrequest-status-reason
 * URL: http://hl7.org/fhir/ValueSet/medicationrequest-status-reason
 * Size: 13 concepts
 */
export const MedicationrequestStatusReasonConcepts = [
    { code: "altchoice", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason" },
    { code: "clarif", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason" },
    { code: "drughigh", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason" },
    { code: "hospadm", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason" },
    { code: "labint", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason" },
    { code: "non-avail", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason" },
    { code: "preg", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason" },
    { code: "salg", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason" },
    { code: "sddi", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason" },
    { code: "sdupther", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason" },
    { code: "sintol", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason" },
    { code: "surg", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason" },
    { code: "washout", system: "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidMedicationrequestStatusReasonCode(code) {
    return MedicationrequestStatusReasonConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getMedicationrequestStatusReasonConcept(code) {
    return MedicationrequestStatusReasonConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const MedicationrequestStatusReasonCodes = MedicationrequestStatusReasonConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomMedicationrequestStatusReasonCode() {
    return MedicationrequestStatusReasonCodes[Math.floor(Math.random() * MedicationrequestStatusReasonCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomMedicationrequestStatusReasonConcept() {
    return MedicationrequestStatusReasonConcepts[Math.floor(Math.random() * MedicationrequestStatusReasonConcepts.length)];
}
