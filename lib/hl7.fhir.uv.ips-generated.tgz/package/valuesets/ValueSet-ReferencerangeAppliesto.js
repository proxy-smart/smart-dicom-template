/**
 * ValueSet: referencerange-appliesto
 * URL: http://hl7.org/fhir/ValueSet/referencerange-appliesto
 * Size: 3 concepts
 */
export const ReferencerangeAppliestoConcepts = [
    { code: "248153007", system: "http://snomed.info/sct" },
    { code: "248152002", system: "http://snomed.info/sct" },
    { code: "77386006", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidReferencerangeAppliestoCode(code) {
    return ReferencerangeAppliestoConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getReferencerangeAppliestoConcept(code) {
    return ReferencerangeAppliestoConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ReferencerangeAppliestoCodes = ReferencerangeAppliestoConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomReferencerangeAppliestoCode() {
    return ReferencerangeAppliestoCodes[Math.floor(Math.random() * ReferencerangeAppliestoCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomReferencerangeAppliestoConcept() {
    return ReferencerangeAppliestoConcepts[Math.floor(Math.random() * ReferencerangeAppliestoConcepts.length)];
}
