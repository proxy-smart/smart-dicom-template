/**
 * ValueSet: data-absent-reason
 * URL: http://hl7.org/fhir/ValueSet/data-absent-reason
 * Size: 15 concepts
 */
export const DataAbsentReasonConcepts = [
    { code: "unknown", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" },
    { code: "asked-unknown", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" },
    { code: "temp-unknown", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" },
    { code: "not-asked", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" },
    { code: "asked-declined", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" },
    { code: "masked", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" },
    { code: "not-applicable", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" },
    { code: "unsupported", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" },
    { code: "as-text", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" },
    { code: "error", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" },
    { code: "not-a-number", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" },
    { code: "negative-infinity", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" },
    { code: "positive-infinity", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" },
    { code: "not-performed", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" },
    { code: "not-permitted", system: "http://terminology.hl7.org/CodeSystem/data-absent-reason" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidDataAbsentReasonCode(code) {
    return DataAbsentReasonConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getDataAbsentReasonConcept(code) {
    return DataAbsentReasonConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const DataAbsentReasonCodes = DataAbsentReasonConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomDataAbsentReasonCode() {
    return DataAbsentReasonCodes[Math.floor(Math.random() * DataAbsentReasonCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomDataAbsentReasonConcept() {
    return DataAbsentReasonConcepts[Math.floor(Math.random() * DataAbsentReasonConcepts.length)];
}
