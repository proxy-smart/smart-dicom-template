/**
 * ValueSet: ucum-vitals-common
 * URL: http://hl7.org/fhir/ValueSet/ucum-vitals-common
 * Size: 12 concepts
 */
export const UcumVitalsCommonConcepts = [
    { code: "%", system: "http://unitsofmeasure.org" },
    { code: "cm", system: "http://unitsofmeasure.org" },
    { code: "[in_i]", system: "http://unitsofmeasure.org" },
    { code: "kg", system: "http://unitsofmeasure.org" },
    { code: "g", system: "http://unitsofmeasure.org" },
    { code: "[lb_av]", system: "http://unitsofmeasure.org" },
    { code: "Cel", system: "http://unitsofmeasure.org" },
    { code: "[degF]", system: "http://unitsofmeasure.org" },
    { code: "mm[Hg]", system: "http://unitsofmeasure.org" },
    { code: "/min", system: "http://unitsofmeasure.org" },
    { code: "kg/m2", system: "http://unitsofmeasure.org" },
    { code: "m2", system: "http://unitsofmeasure.org" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidUcumVitalsCommonCode(code) {
    return UcumVitalsCommonConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getUcumVitalsCommonConcept(code) {
    return UcumVitalsCommonConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const UcumVitalsCommonCodes = UcumVitalsCommonConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomUcumVitalsCommonCode() {
    return UcumVitalsCommonCodes[Math.floor(Math.random() * UcumVitalsCommonCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomUcumVitalsCommonConcept() {
    return UcumVitalsCommonConcepts[Math.floor(Math.random() * UcumVitalsCommonConcepts.length)];
}
