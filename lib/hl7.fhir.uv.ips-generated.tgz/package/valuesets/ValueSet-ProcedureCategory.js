/**
 * ValueSet: procedure-category
 * URL: http://hl7.org/fhir/ValueSet/procedure-category
 * Size: 7 concepts
 */
export const ProcedureCategoryConcepts = [
    { code: "24642003", system: "http://snomed.info/sct" },
    { code: "409063005", system: "http://snomed.info/sct" },
    { code: "409073007", system: "http://snomed.info/sct" },
    { code: "387713003", system: "http://snomed.info/sct" },
    { code: "103693007", system: "http://snomed.info/sct" },
    { code: "46947000", system: "http://snomed.info/sct" },
    { code: "410606002", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidProcedureCategoryCode(code) {
    return ProcedureCategoryConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getProcedureCategoryConcept(code) {
    return ProcedureCategoryConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ProcedureCategoryCodes = ProcedureCategoryConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomProcedureCategoryCode() {
    return ProcedureCategoryCodes[Math.floor(Math.random() * ProcedureCategoryCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomProcedureCategoryConcept() {
    return ProcedureCategoryConcepts[Math.floor(Math.random() * ProcedureCategoryConcepts.length)];
}
