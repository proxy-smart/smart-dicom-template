/**
 * ValueSet: resource-types
 * URL: http://hl7.org/fhir/ValueSet/resource-types
 * Size: 148 concepts
 */
interface ResourceTypesConceptDef {
    readonly code: string;
    readonly system: string;
    readonly display?: string;
}
export declare const ResourceTypesConcepts: readonly ResourceTypesConceptDef[];
/** String type (ValueSet too large for union type) */
export type ResourceTypesCode = string;
/** Type representing a concept from this ValueSet */
export type ResourceTypesConcept = ResourceTypesConceptDef;
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidResourceTypesCode(code: string): code is ResourceTypesCode;
/**
 * Get concept details by code
 */
export declare function getResourceTypesConcept(code: string): ResourceTypesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const ResourceTypesCodes: string[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomResourceTypesCode(): ResourceTypesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomResourceTypesConcept(): ResourceTypesConcept;
export {};
