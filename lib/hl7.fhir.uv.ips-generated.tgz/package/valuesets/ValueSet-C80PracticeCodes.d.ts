/**
 * ValueSet: c80-practice-codes
 * URL: http://hl7.org/fhir/ValueSet/c80-practice-codes
 * Size: 117 concepts
 */
interface C80PracticeCodesConceptDef {
    readonly code: string;
    readonly system: string;
    readonly display?: string;
}
export declare const C80PracticeCodesConcepts: readonly C80PracticeCodesConceptDef[];
/** String type (ValueSet too large for union type) */
export type C80PracticeCodesCode = string;
/** Type representing a concept from this ValueSet */
export type C80PracticeCodesConcept = C80PracticeCodesConceptDef;
/**
 * Check if a code is valid in this ValueSet
 */
export declare function isValidC80PracticeCodesCode(code: string): code is C80PracticeCodesCode;
/**
 * Get concept details by code
 */
export declare function getC80PracticeCodesConcept(code: string): C80PracticeCodesConcept | undefined;
/**
 * Array of all valid codes (for runtime checks)
 */
export declare const C80PracticeCodesCodes: string[];
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export declare function randomC80PracticeCodesCode(): C80PracticeCodesCode;
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export declare function randomC80PracticeCodesConcept(): C80PracticeCodesConcept;
export {};
