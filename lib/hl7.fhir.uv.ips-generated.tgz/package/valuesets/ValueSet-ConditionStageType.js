/**
 * ValueSet: condition-stage-type
 * URL: http://hl7.org/fhir/ValueSet/condition-stage-type
 * Size: 2 concepts
 */
export const ConditionStageTypeConcepts = [
    { code: "261023001", system: "http://snomed.info/sct" },
    { code: "260998006", system: "http://snomed.info/sct" },
];
/**
 * Check if a code is valid in this ValueSet
 */
export function isValidConditionStageTypeCode(code) {
    return ConditionStageTypeConcepts.some(c => c.code === code);
}
/**
 * Get concept details by code
 */
export function getConditionStageTypeConcept(code) {
    return ConditionStageTypeConcepts.find(c => c.code === code);
}
/**
 * Array of all valid codes (for runtime checks)
 */
export const ConditionStageTypeCodes = ConditionStageTypeConcepts.map(c => c.code);
/**
 * Pick a random code from this ValueSet (for test data generation)
 */
export function randomConditionStageTypeCode() {
    return ConditionStageTypeCodes[Math.floor(Math.random() * ConditionStageTypeCodes.length)];
}
/**
 * Pick a random concept from this ValueSet (includes system and display)
 */
export function randomConditionStageTypeConcept() {
    return ConditionStageTypeConcepts[Math.floor(Math.random() * ConditionStageTypeConcepts.length)];
}
